MARKETPLACE HUB - WEB TECHNOLOGY LAB TASK 02

Project: Online marketplace with four user categories: Admin, Customer, Manager, and Seller.

HOW TO RUN
1. Extract the ZIP folder.
2. Open WT_LabTask1_HTML/index.html in any modern web browser.
3. Use the horizontal navigation menu to open the login and registration pages.
4. The project uses HTML and an external CSS file. No server or database is required for this front-end demonstration.

CSS FILE
css/style.css

CSS CONCEPTS DEMONSTRATED
- External CSS stylesheet
- Element selectors, class selectors, and the #login-page / #registration-page ID selectors
- :hover pseudo-class and hover transitions
- Box model: margin, padding, border, box-sizing
- border-radius and box-shadow
- Position: sticky navigation, relative page/hero sections, absolute decorative element, fixed quick-login link
- Display properties and Flexbox
- CSS Grid for user cards, dashboard cards, and form layout
- max-width responsive layout and media queries
- z-index and overflow
- Background, font, text styling, and CSS units (px, rem, %, vw, vh through layout/typography)

NOTES
- Forms are front-end demonstrations and do not save or verify account data because no backend/database was requested.
- commonui/home.html is an alternate homepage and index.html is the main entry page.
