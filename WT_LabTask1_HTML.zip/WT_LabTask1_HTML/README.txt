Marketplace Hub - HTML-only Web Technology Lab Task 1

How to run:
1. Extract the ZIP file.
2. Open index.html in a web browser.
3. Use the links to open the login and registration pages.

This project uses HTML only. It contains no CSS, JavaScript, PHP, or database connection.
The forms are demonstration forms; they do not save registration details or authenticate users.

Folders:
admin/      Admin registration and dashboard
customer/   Customer registration and dashboard
manager/    Manager registration and dashboard
seller/     Seller registration and dashboard
commonui/   Shared homepage and login page
